package za.ac.tut.bl;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import java.util.List;
import za.ac.tut.entity.Player;

@Stateless
public class PlayerFacade extends AbstractFacade<Player> implements PlayerFacadeLocal {

    @PersistenceContext(unitName = "PlayerEJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PlayerFacade() {
        super(Player.class);
    }    

    @Override
    public Player findByUsername(String username) {
        try {
            return em.createQuery("SELECT p FROM Player p WHERE p.username = :username", Player.class)
                    .setParameter("username", username)
                    .getSingleResult();
        } catch (Exception e) {
            return null; 
        }
    }

    @Override
    public Player findByEmail(String email) {
        try {
            return em.createQuery("SELECT p FROM Player p WHERE p.email = :email", Player.class)
                    .setParameter("email", email)
                    .getSingleResult();
        } catch (Exception e) {
            return null; 
        }
    }

    @Override
    public List<Player> leaderboardPlayers() {
     String queryStr="SELECT p FROM Player p ORDER BY p.score DESC";
     Query query=em.createQuery(queryStr);
     List<Player> players=query.getResultList();
    
     return players;
    }
}