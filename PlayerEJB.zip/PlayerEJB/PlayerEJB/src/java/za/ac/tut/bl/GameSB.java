/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatefulEjbClass.java to edit this template
 */
package za.ac.tut.bl;

import jakarta.ejb.EJB;
import jakarta.ejb.Stateful;
import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import za.ac.tut.entity.Player;

@Stateful
public class GameSB {
    @EJB private PlayerFacadeLocal pfl;

    private List<String> scrambledWords = new ArrayList<>(Arrays.asList(
        "mlac", "tsof", "iuteq", "asye", "lhtgi", "gtnlee", "mpslei", "looc", "dlmi", "xrealed",
        "civtae", "hpars", "scofude", "lreac", "rksib", "imfr", "alert", "thbrgi", "adsety", "idlos",
        "tneisne", "udlo", "oewrlpfu", "irdnev", "gnereeitc", "ldbo", "tsianpsaoe", "adeeth", "idvvi", "rhad",
        "suroufi", "gmboino", "epsoixelv", "creife", "idlw", "syomrto", "agnirg", "ugbrinn", "neipircg", "evesre",
        "abglzni", "adtaseinvg", "ltnlrcooonbau", "veagsa", "eoltvni", "saoctapicrth", "lhsyiectra", "cmanai", "canilov", "ocaplapycit"
    ));

    private List<String> actualWords = new ArrayList<>(Arrays.asList(
        "calm", "soft", "quiet", "easy", "light", "gentle", "simple", "cool", "mild", "relaxed",
        "active", "sharp", "focused", "clear", "brisk", "firm", "alert", "bright", "steady", "solid",
        "intense", "loud", "powerful", "driven", "energetic", "bold", "passionate", "heated", "vivid", "hard",
        "furious", "booming", "explosive", "fierce", "wild", "stormy", "raging", "burning", "piercing", "severe",
        "blazing", "devastating", "uncontrollable", "savage", "violent", "catastrophic", "hysterical", "manic", "volcanic", "apocalyptic"
    ));

    private Integer index=0;
    private Integer score=0;
    private String currentScrambledWord=scrambledWords.get(0);
    private String feedback;
    private Long lastTime;

    public void reset(HttpSession session){
        index=0;
        score=0;
        session.setAttribute("score", score);
        session.setAttribute("index", index);
    }
    
    public String firstWord(){
        return scrambledWords.get(0);
    }
    public String getCurrentScrambledWord() {
        return scrambledWords.get(index); //get scrumbled word from arraylist with updated index or 0
    }
    

    public int getScore() {
        return score;
    }


    public String checkGuess(HttpSession session,String guess) { //pass in session and user guess
        String actualWord = actualWords.get(index); //get correct word using updated index
        if (guess.equalsIgnoreCase(actualWord)) {
            score += 10;
            session.setAttribute("score", score); //set updated score to session
            return "Correct! You unscrambled the word. You earned 10 points.";
        } else {
            return "Oops! Try again";
        }
    }

    public void moveToNextWord() { //update index when this method is called after "Check" button
        index++;
        if (index >= scrambledWords.size()) {
            index = 0; // Reset to the beginning if end is reached
        }
    }
}
