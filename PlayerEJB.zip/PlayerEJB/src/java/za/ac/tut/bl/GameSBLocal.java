/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/SessionLocal.java to edit this template
 */
package za.ac.tut.bl;

import jakarta.ejb.Local;
import jakarta.servlet.http.HttpSession;

/**
 *
 * @author themb
 */
@Local
public interface GameSBLocal {

    String getCurrentScrambledWord();

    int getScore();

    String checkGuess(HttpSession session, String guess);

    void moveToNextWord();
}
