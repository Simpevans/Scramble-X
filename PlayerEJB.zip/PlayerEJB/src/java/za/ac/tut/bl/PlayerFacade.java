package za.ac.tut.bl;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import za.ac.tut.entity.Player;

@Stateless
public class PlayerFacade extends AbstractFacade<Player> implements PlayerFacadeLocal {

    @PersistenceContext(unitName = "PlayerEJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PlayerFacade() {
        super(Player.class);
    }    
}