/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ac.za.tut.entity;

import jakarta.ejb.Local;
import java.util.List;

/**
 *
 * @author Boitshepo Mosupi
 */
@Local
public interface PlayerFacadeLocal {

    void create(Player player);

    void edit(Player player);

    void remove(Player player);

    Player find(Object id);

    List<Player> findAll();

    List<Player> findRange(int[] range);

    int count();
    
    Player findByUsername(String username);
}
