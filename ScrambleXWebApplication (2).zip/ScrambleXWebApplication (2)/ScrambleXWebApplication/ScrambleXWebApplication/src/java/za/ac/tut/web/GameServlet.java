package za.ac.tut.web;

import jakarta.ejb.EJB;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import za.ac.tut.bl.GameSB;
import za.ac.tut.bl.PlayerFacadeLocal;
import za.ac.tut.entity.Player;


public class GameServlet extends HttpServlet {
    @EJB
    private PlayerFacadeLocal pfl;
    
    
    @EJB
    GameSB bean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(); //get current session
        bean.reset(session); //reset index and score since new game
        session.setAttribute("score", 0);
        Player player=(Player)session.getAttribute("player");
        player.setScore(0);
        pfl.edit(player); //edit score back to zero that is in database
        
        request.setAttribute("scrambledWord", bean.getCurrentScrambledWord());
        
        request.getRequestDispatcher("game.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(); //get current session

        // Get the user guess and button clicked
        String word = request.getParameter("userGuess");
        String buttonClicked = request.getParameter("param");

        String feedback = bean.checkGuess(session, word); //method updates score and provides feedback
        session.setAttribute("feedback", feedback); //set feedback;

        // Handle button clicks
        if ("Check".equals(buttonClicked)) {
            bean.moveToNextWord(); //tells index to move to the next word

            request.setAttribute("scrambledWord", bean.getCurrentScrambledWord()); //after index is updated, is used to retrieve next scrumbled word , done in session bean
            request.setAttribute("feedback", feedback); //send feedback of previous play

            // Forward to the JSP for display
            request.getRequestDispatcher("game.jsp").forward(request, response);
        } else if ("Submit".equals(buttonClicked)) {
            Player player=(Player)session.getAttribute("player");
            Integer score=(Integer)session.getAttribute("score");
            player.setScore(score);
            pfl.edit(player); //update score in database
            // Redirect to leaderboard on "Submit"
            response.sendRedirect("score.jsp");
        } 
    }

}
