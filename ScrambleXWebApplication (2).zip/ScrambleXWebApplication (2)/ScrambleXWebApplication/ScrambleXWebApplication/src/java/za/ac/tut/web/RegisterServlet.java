/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import za.ac.tut.entity.Player;

import jakarta.ejb.EJB;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Date;
import za.ac.tut.bl.PlayerFacadeLocal;

/**
 *
 * @author Boitshepo Mosupi
 */
public class RegisterServlet extends HttpServlet {

    @EJB
    PlayerFacadeLocal pf1;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");

        Player player = new Player();

        player.setUsername(username);
        player.setPassword(password);
        player.setEmail(email);
        player.setScore(0);
        player.setRegistrationDate(new Date());

        pf1.create(player);

        response.sendRedirect("login.jsp");

    }

}
