package za.ac.tut.web;

import jakarta.ejb.EJB;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;
import za.ac.tut.bl.PlayerFacadeLocal;
import za.ac.tut.entity.Player;


public class LeaderboardServlet extends HttpServlet {
     @EJB private PlayerFacadeLocal pfl;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Player> players= pfl.leaderboardPlayers();
            if(players==null){
                players= new ArrayList<>();
            }
        request.setAttribute("players", players);
        
        RequestDispatcher disp= request.getRequestDispatcher("leaderboard.jsp");
        disp.forward(request, response);
    }

}
