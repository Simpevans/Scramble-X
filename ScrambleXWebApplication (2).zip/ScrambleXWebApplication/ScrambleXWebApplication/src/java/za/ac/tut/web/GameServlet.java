package za.ac.tut.web;

import jakarta.ejb.EJB;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import za.ac.tut.bl.PlayerFacadeLocal;

public class GameServlet extends HttpServlet {
    
    @EJB
    PlayerFacadeLocal pfl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        
        // Declaring words arrays
        String[] scrambledWords = {"mlac", "tsof", "iuteq", "asye", "lhtgi", "gtnlee", "mpslei", "looc", "dlmi", "xrealed",
                                   "civtae", "hpars", "scofude", "lreac", "rksib", "imfr", "alert", "thbrgi", "adsety", "idlos",
                                   "tneisne", "udlo", "oewrlpfu", "irdnev", "gnereeitc", "ldbo", "tsianpsaoe", "adeeth", "idvvi", "rhad",
                                   "suroufi", "gmboino", "epsoixelv", "creife", "idlw", "syomrto", "agnirg", "ugbrinn", "neipircg", "evesre",
                                   "abglzni", "adtaseinvg", "ltnlrcooonbau", "veagsa", "eoltvni", "saoctapicrth", "lhsyiectra", "cmanai", "canilov", "ocaplapycit"
                                  };

        String[] correctWords = {"calm", "soft", "quiet", "easy", "light", "gentle", "simple", "cool", "mild", "relaxed",
                                 "active", "sharp", "focused", "clear", "brisk", "firm", "alert", "bright", "steady", "solid",
                                 "intense", "loud", "powerful", "driven", "energetic", "bold", "passionate", "heated", "vivid", "hard",
                                 "furious", "booming", "explosive", "fierce", "wild", "stormy", "raging", "burning", "piercing", "severe",
                                 "blazing", "devastating", "uncontrollable", "savage", "violent", "catastrophic", "hysterical", "manic", "volcanic", "apocalyptic"
                                };
        // Declaring controll variables
        Integer index = 0;
        Integer score = 0;
        
        // Retrieving values
        String word = request.getParameter("userGuess");
        String buttonClicked = request.getParameter("param");
        String theWord = correctWords[index];
        
        // Checking the clicked button
        if (buttonClicked.equals("Check"))
        {
            if (word.equalsIgnoreCase(theWord))
            {
                score++;
            }
            
            index++;
            
            session.setAttribute("words", scrambledWords);
            session.setAttribute("score", score);
            session.setAttribute("index", index);
            session.setAttribute("lastTime", System.currentTimeMillis());
            
            RequestDispatcher d = request.getRequestDispatcher(request.getRequestURI()); // Get the current page URL 
            d.forward(request, response);// Redirect to the same page
        }
        else
            if (buttonClicked.equals("Submit"))
            {
                response.sendRedirect("leaderboard.jsp");
            }
    }    
}
