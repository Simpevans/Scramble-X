/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import jakarta.ejb.EJB;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import za.ac.tut.bl.PlayerFacadeLocal;
import za.ac.tut.entity.Player;

public class ForgotPasswordServlet extends HttpServlet {

    @EJB
    private PlayerFacadeLocal pfl;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String resetEmail = request.getParameter("email");
        
        Player player = pfl.findByEmail(resetEmail);
            
        if(player != null){
            // Pass email forward in the URL or session (cleaner with session)
            session.setAttribute("resetEmail", resetEmail);
            session.setMaxInactiveInterval(30 * 60);
            response.sendRedirect("reset_password.jsp");
        }else{
            request.setAttribute("errorMessage", "No account found with that email.");
            request.getRequestDispatcher("forgot_password.jsp").forward(request, response);
        }
    }

}
