package za.ac.tut.web;

import jakarta.ejb.EJB;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import za.ac.tut.bl.PlayerFacadeLocal;
import za.ac.tut.entity.Player;

public class LoginServlet extends HttpServlet {

    @EJB
    private PlayerFacadeLocal pfl;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Fetch the player from DB by username
        Player player = pfl.findByUsername(username);

        if (player != null && player.getPassword().equals(password)) {
            HttpSession session = request.getSession();
            session.setAttribute("player", player);
            session.setMaxInactiveInterval(30 * 60);
            response.sendRedirect("game.jsp");
        } else {
            request.setAttribute("errorMessage", "Invalid username or password.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
