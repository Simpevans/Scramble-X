/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import jakarta.ejb.EJB;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import za.ac.tut.bl.PlayerFacadeLocal;
import za.ac.tut.entity.Player;

public class ResetPasswordServlet extends HttpServlet {

    @EJB
    private PlayerFacadeLocal pfl;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        
        String newPassword = request.getParameter("newPassword");
        String confirmedPassword = request.getParameter("confirmPassword");
        
        String email = (String) session.getAttribute("resetEmail");

        if (newPassword.equals(confirmedPassword) && email != null) {
            Player player = pfl.findByEmail(email); 
            if (player != null) {
                player.setPassword(newPassword);
                pfl.edit(player);

                session.removeAttribute("resetEmail");
                request.setAttribute("message", "Password successfully reset.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            } else {
                request.setAttribute("errorMessage", "Something went wrong. Try again.");
                request.getRequestDispatcher("reset_password.jsp").forward(request, response);
            }
        } else {
            request.setAttribute("errorMessage", "Passwords do not match.");
            request.getRequestDispatcher("reset_password.jsp").forward(request, response);
        }
    
    }

}
